<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gaadiwala | Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.jsp" style="text-decoration:none; color:inherit;">Gaadi<span>wala</span></a>
        </div>
        <nav>
            <a href="index.jsp">Home</a>
            <a href="vehicles.jsp">Vehicles</a>
            <a href="login.jsp" class="active">Login</a>
            <a href="register.jsp">Register</a>
        </nav>
    </header>
    
    <div class="form-box">
        <h2>Account Login</h2>
        
        <%-- Optional: Automatically catches error alerts sent back by your LoginServlet --%>
        <% if (request.getAttribute("errorMessage") != null) { %>
            <div style="color: #e11d48; background: #fff1f2; border: 1px solid #ffe4e6; padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; text-align: center;">
                <%= request.getAttribute("errorMessage") %>
            </div>
        <% } %>
        
        <form action="LoginServlet" method="POST">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" required autocomplete="off">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn-primary" style="width: 100%;">Sign In</button>
        </form>
    </div>
</body>
</html>