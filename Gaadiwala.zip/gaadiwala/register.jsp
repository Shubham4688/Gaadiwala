<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    String statusMessage = "";
    String statusType = ""; // Options: "success" or "error"

    // Process database submission when the form sends a POST request
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        Connection c = null;
        PreparedStatement p = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
            
            // OPTION A: Use this query if your MySQL 'users' table has a 'phone' column:
            String sql = "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)";
            p = c.prepareStatement(sql);
            p.setString(1, request.getParameter("name")); 
            p.setString(2, request.getParameter("email")); 
            p.setString(3, request.getParameter("phone")); 
            p.setString(4, request.getParameter("password"));
            
            /* // OPTION B: If you get a database error saying 'phone' column doesn't exist,
            // comment out Option A, remove the /* symbols, and use this 3-value fallback:
            String sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
            p = c.prepareStatement(sql);
            p.setString(1, request.getParameter("name")); 
            p.setString(2, request.getParameter("email")); 
            p.setString(3, request.getParameter("password"));
            */

            int result = p.executeUpdate();
            if (result > 0) {
                statusMessage = "Registration Successful! You can now log in.";
                statusType = "success";
            }
        } catch (Exception e) {
            statusMessage = "Database Error: " + e.getMessage();
            statusType = "error";
        } finally {
            if (p != null) try { p.close(); } catch (Exception e) {}
            if (c != null) try { c.close(); } catch (Exception e) {}
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Gaadiwala | Register</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Clean helper styling to display the database confirmation message layout */
        .status-banner { padding: 12px; margin-bottom: 15px; border-radius: 4px; text-align: center; font-weight: 600; font-family: sans-serif; }
        .status-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .status-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <header>
        <div class="logo"><a href="index.jsp" style="text-decoration:none; color:inherit;">Gaadi<span>wala</span></a></div>
        <nav>
            <a href="index.jsp">Home</a>
            <a href="vehicles.jsp">Vehicles</a>
            <a href="login.jsp">Login</a>
            <a href="register.jsp" class="active">Register</a>
        </nav>
    </header>
    
    <div class="form-box">
        <h2>Create Account</h2>
        
        <%-- Displays dynamic database feedback banner if set --%>
        <% if (!statusMessage.isEmpty()) { %>
            <div class="status-banner status-<%= statusType %>">
                <%= statusMessage %>
            </div>
        <% } %>

        <form action="register.jsp" method="POST">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="phone" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn-primary" style="width: 100%;">Register</button>
        </form>
    </div>
</body>
</html>