<%@ page import="java.sql.*"%>
<%
Class.forName("com.mysql.cj.jdbc.Driver");
Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala","root","Shubham@4688");
PreparedStatement p=c.prepareStatement("insert into bookings(vehicle_id,booking_date) values(?,curdate())");
p.setInt(1,Integer.parseInt(request.getParameter("id"))); p.executeUpdate(); c.close();
%>Booked Successfully <a href='vehicles.jsp'>Back</a>