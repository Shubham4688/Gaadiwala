package com.gaadiwala;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/BookVehicleServlet")
public class BookVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession s = req.getSession(false); 
        
        // CORRECTION 1: Fixed redirect from login.html to login.jsp
        if(s == null || s.getAttribute("user_id") == null) { 
            res.sendRedirect("login.jsp"); 
            return; 
        }
        
        int uId = (Integer) s.getAttribute("user_id"); 
        int vId = Integer.parseInt(req.getParameter("vehicle_id"));
        String start = req.getParameter("start_date"); 
        String end = req.getParameter("end_date");
        
        Connection c = null;
        PreparedStatement psP = null;
        PreparedStatement ps = null;
        PreparedStatement psU = null;
        ResultSet rs = null;
        
        try { 
            // Calculate inclusive days (e.g., Same day booking = 1 day)
            long days = ChronoUnit.DAYS.between(LocalDate.parse(start), LocalDate.parse(end)) + 1; 
            if(days <= 0) days = 1;
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // CORRECTION 2: Updated MySQL password to match your working local configuration
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
            
            // Fetch the vehicle rental rate
            psP = c.prepareStatement("SELECT price_per_day FROM vehicles WHERE id=?"); 
            psP.setInt(1, vId);
            rs = psP.executeQuery(); 
            
            double rate = 2000.0; 
            if(rs.next()) { 
                rate = rs.getDouble("price_per_day"); 
            }
            
            // Insert the booking log row
            ps = c.prepareStatement("INSERT INTO bookings (user_id, vehicle_id, start_date, end_date, total_price, status) VALUES (?, ?, ?, ?, ?, 'CONFIRMED')");
            ps.setInt(1, uId); 
            ps.setInt(2, vId); 
            ps.setString(3, start); 
            ps.setString(4, end); 
            ps.setDouble(5, (rate * days));
            ps.executeUpdate(); 
            
            // OPTIONAL IMPROVEMENT: Automatically flip the vehicle status to 'BOOKED' so the fleet UI updates instantly
            psU = c.prepareStatement("UPDATE vehicles SET status = 'BOOKED' WHERE id = ?");
            psU.setInt(1, vId);
            psU.executeUpdate();
            
            // CORRECTION 3: Secure bulletproof routing back to your active dashboard module
            res.sendRedirect(req.getContextPath() + "/dashboard.jsp"); 
            
        } catch(Exception e) { 
            e.printStackTrace();
            res.sendRedirect("vehicles.jsp?error=failed"); 
        } finally {
            // Clean up resources reliably
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (psP != null) psP.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (psU != null) psU.close(); } catch (Exception e) {}
            try { if (c != null) c.close(); } catch (Exception e) {}
        }
    }
}