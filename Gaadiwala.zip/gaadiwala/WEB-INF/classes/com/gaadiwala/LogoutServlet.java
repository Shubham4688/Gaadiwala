package com.gaadiwala;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession s = req.getSession(false); 
        if(s != null) {
            s.invalidate(); 
        }
        // FIX: Redirect to login.jsp using the correct context path
        res.sendRedirect(req.getContextPath() + "/login.jsp");
    }
}