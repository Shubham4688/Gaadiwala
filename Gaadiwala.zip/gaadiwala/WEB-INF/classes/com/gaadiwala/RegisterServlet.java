package com.gaadiwala;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try { Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "root");
            PreparedStatement ps = c.prepareStatement("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
            ps.setString(1, req.getParameter("name")); ps.setString(2, req.getParameter("email"));
            ps.setString(3, req.getParameter("phone")); ps.setString(4, req.getParameter("password"));
            ps.executeUpdate(); res.sendRedirect("login.html?success"); c.close();
        } catch(Exception e) { res.sendRedirect("register.html"); }
    }
}