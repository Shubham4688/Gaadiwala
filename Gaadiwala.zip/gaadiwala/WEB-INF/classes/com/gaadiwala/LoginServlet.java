package com.gaadiwala;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String em = req.getParameter("email"); 
        String pw = req.getParameter("password");
        
        Connection c = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try { 
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
            
            ps = c.prepareStatement("SELECT id, name FROM users WHERE email=? AND password=?");
            ps.setString(1, em); 
            ps.setString(2, pw); 
            
            rs = ps.executeQuery();
            
            if(rs.next()) { 
                HttpSession s = req.getSession(); 
                s.setAttribute("user_id", rs.getInt("id")); 
                s.setAttribute("user_name", rs.getString("name")); 
                
                // FIX: Removed the duplicate "/gaadiwala" segment
                res.sendRedirect(req.getContextPath() + "/dashboard.jsp");
            } else { 
                req.setAttribute("errorMessage", "Invalid email address or password.");
                req.getRequestDispatcher("login.jsp").forward(req, res);
            } 
        } catch(Exception e) { 
            req.setAttribute("errorMessage", "Database Connection Refused: " + e.getMessage());
            req.getRequestDispatcher("login.jsp").forward(req, res);
        } finally {
            try { if(rs != null) rs.close(); } catch(Exception e) {}
            try { if(ps != null) ps.close(); } catch(Exception e) {}
            try { if(c != null) c.close(); } catch(Exception e) {}
        }
    }
}