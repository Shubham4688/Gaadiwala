<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gaadiwala | Premium Self-Drive Rentals India</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --dark-bg: #0f172a;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
            scroll-behavior: smooth;
        }

        body {
            background-color: #ffffff;
            color: var(--text-main);
        }

        /* --- NAVIGATION HEADER --- */
        header {
            background-color: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(10px);
            padding: 18px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        header .logo {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -0.5px;
            text-decoration: none;
        }

        header .logo span {
            color: var(--primary);
        }

        nav {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        nav a {
            color: #cbd5e1;
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        nav a:hover, nav a.active {
            color: #ffffff;
        }

        .nav-btn {
            background-color: var(--primary);
            color: white;
            padding: 9px 20px;
            border-radius: 6px;
            font-weight: 600;
        }

        .nav-btn:hover {
            background-color: var(--primary-hover);
        }

        /* --- HERO PREMIUM AREA --- */
        .hero {
            background: linear-gradient(rgba(15, 23, 42, 0.65), rgba(15, 23, 42, 0.85)), 
                        url('https://owltourism.az/wp-content/uploads/2024/06/Transaction-Tracking-and-Analytics-Steering-Car-Rental-banner.webp') no-repeat center center/cover;
            height: 85vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            padding: 0 20px;
            margin-top: 0;
        }

        .hero h1 {
            font-size: 52px;
            font-weight: 800;
            letter-spacing: -1px;
            margin-bottom: 16px;
            max-width: 800px;
            line-height: 1.2;
        }

        .hero h1 span {
            background: linear-gradient(to right, #3b82f6, #60a5fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero p {
            font-size: 19px;
            margin-bottom: 35px;
            color: #94a3b8;
            max-width: 600px;
            font-weight: 400;
        }

        .btn-cta {
            background-color: var(--primary);
            color: white;
            padding: 15px 38px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);
            transition: all 0.3s ease;
        }

        .btn-cta:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.6);
        }

        /* --- SECTION CONTROLLERS --- */
        .section-container {
            max-width: 1240px;
            margin: 80px auto;
            padding: 0 24px;
        }

        .section-header {
            text-align: center;
            margin-bottom: 50px;
        }

        .section-header h2 {
            font-size: 34px;
            font-weight: 700;
            color: var(--dark-bg);
            margin-bottom: 10px;
            letter-spacing: -0.5px;
        }

        .section-header p {
            color: var(--text-muted);
            font-size: 16px;
        }

        /* --- HOW IT WORKS GRID --- */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 20px;
        }

        .step-card {
            background: var(--light-bg);
            padding: 40px 30px;
            border-radius: 12px;
            text-align: center;
            border: 1px solid #e2e8f0;
            transition: transform 0.3s ease, background 0.3s ease;
        }

        .step-card:hover {
            transform: translateY(-5px);
            background: #ffffff;
            box-shadow: var(--card-shadow);
        }

        .step-icon {
            width: 60px;
            height: 60px;
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 700;
            margin: 0 auto 20px;
        }

        .step-card h3 {
            font-size: 19px;
            font-weight: 600;
            margin-bottom: 12px;
            color: var(--dark-bg);
        }

        .step-card p {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        /* --- FLEET PREVIEW GALLERY --- */
        .fleet-preview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
        }

        .fleet-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
            transition: all 0.3s ease;
        }

        .fleet-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--card-shadow);
        }

        .fleet-img-wrapper {
            width: 100%;
            height: 190px;
            position: relative;
            background-color: #e2e8f0;
        }

        .fleet-img-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .badge-type {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(15, 23, 42, 0.85);
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .fleet-info {
            padding: 24px;
        }

        .fleet-info h3 {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 6px;
            color: var(--dark-bg);
        }

        .fleet-specs {
            display: flex;
            gap: 15px;
            color: var(--text-muted);
            font-size: 13px;
            margin-bottom: 16px;
            border-bottom: 1px solid #f1f5f9;
            padding-bottom: 12px;
        }

        .fleet-pricing {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .fleet-pricing .rent-cost {
            font-size: 18px;
            font-weight: 700;
            color: #059669;
        }

        .fleet-pricing .rent-cost span {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 400;
        }

        /* --- CORPORATE SYSTEM FOOTER --- */
        footer {
            background-color: var(--dark-bg);
            color: #94a3b8;
            padding: 60px 8% 30px;
            border-top: 1px solid rgba(255,255,255,0.05);
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-brand h3 {
            color: white;
            font-size: 22px;
            margin-bottom: 15px;
            font-weight: 700;
        }

        .footer-brand h3 span {
            color: var(--primary);
        }

        .footer-brand p {
            font-size: 14px;
            line-height: 1.6;
        }

        .footer-links h4 {
            color: #f1f5f9;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links ul li {
            margin-bottom: 12px;
        }

        .footer-links ul li a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s ease;
        }

        .footer-links ul li a:hover {
            color: white;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.05);
            padding-top: 30px;
            text-align: center;
            font-size: 13px;
        }
    </style>
</head>
<body>

    <header>
        <a href="index.jsp" class="logo">Gaadi<span>wala</span></a>
        <nav>
            <a href="index.jsp" class="active">Home</a>
            <a href="vehicles.jsp">Vehicles</a>
            <a href="login.jsp">Login</a>
            <a href="register.jsp" class="nav-btn">Sign Up</a>
        </nav>
    </header>

    <section class="hero">
        <h1>Your Premium Journey Starts <span>Right Here</span></h1>
        <p>Experience India's top-rated self-drive car and cruiser bike ecosystem. Zero hidden fees. 100% verified luxury assets.</p>
        <a href="vehicles.jsp" class="btn-cta">Available for Rent</a>
    </section>

    <section class="section-container">
        <div class="section-header">
            <h2>How It Works</h2>
            <p>Rent your favorite drive in three seamless corporate processing loops.</p>
        </div>
        <div class="steps-grid">
            <div class="step-card">
                <div class="step-icon">1</div>
                <h3>Select Your Ride</h3>
                <p>Browse through our deeply customized variety of luxury SUVs, sedans, and cruisers across major operational sectors.</p>
            </div>
            <div class="step-card">
                <div class="step-icon">2</div>
                <h3>Pick Timelines</h3>
                <p>Specify your required start and terminal dates dynamically. Our system schedules and computes absolute transparent rates.</p>
            </div>
            <div class="step-card">
                <div class="step-icon">3</div>
                <h3>Drive Off</h3>
                <p>Complete authentication checkpoints, pick up the key from your hub allocations, and navigate your destination boundary.</p>
            </div>
        </div>
    </section>

    <section class="section-container">
        <div class="section-header">
            <h2>Spotlight Fleet Categories</h2>
            <p>Take a look at some of our most highly requested premium options inside India.</p>
        </div>
        <div class="fleet-preview-grid">
            
            <div class="fleet-card">
                <div class="fleet-img-wrapper">
                    <span class="badge-type">4x4 SUV</span>
                    <img src="https://auto.mahindra.com/on/demandware.static/-/Sites-amc-Library/default/dw70ae4c63/press-release/New-thar-1529x911.jpg">
                </div>
                <div class="fleet-info">
                    <h3>Mahindra Thar</h3>
                    <div class="fleet-specs">
                        <span>⛽ Diesel</span>
                        <span>⚙️ Manual/Auto</span>
                    </div>
                    <div class="fleet-pricing">
                        <div class="rent-cost">₹4,000 <span>/ day</span></div>
                        <a href="vehicles.jsp" class="nav-btn" style="padding: 6px 14px; font-size: 13px;">Details</a>
                    </div>
                </div>
            </div>

            <div class="fleet-card">
                <div class="fleet-img-wrapper">
                    <span class="badge-type">Sedan</span>
                    <img src="https://images.autox.com/uploads/2025/06/Honda-City-Sport-1750408164518-500x261.webp">
                </div>
                <div class="fleet-info">
                    <h3>Honda City i-VTEC</h3>
                    <div class="fleet-specs">
                        <span>⛽ Petrol</span>
                        <span>⚙️ Smooth Manual</span>
                    </div>
                    <div class="fleet-pricing">
                        <div class="rent-cost">₹2,500 <span>/ day</span></div>
                        <a href="vehicles.jsp" class="nav-btn" style="padding: 6px 14px; font-size: 13px;">Details</a>
                    </div>
                </div>
            </div>

            <div class="fleet-card">
                <div class="fleet-img-wrapper">
                    <span class="badge-type">Cruiser Bike</span>
                    <img src="https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF2307.JPG?w=640">
                </div>
                <div class="fleet-info">
                    <h3>RE Classic 350</h3>
                    <div class="fleet-specs">
                        <span>⛽ Petrol</span>
                        <span>🏍️ Cruising Core</span>
                    </div>
                    <div class="fleet-pricing">
                        <div class="rent-cost">₹1,200 <span>/ day</span></div>
                        <a href="vehicles.jsp" class="nav-btn" style="padding: 6px 14px; font-size: 13px;">Details</a>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-grid">
            <div class="footer-brand">
                <h3>Gaadi<span>wala</span></h3>
                <p>India's leading tech-driven vehicle network platform, deploying clean hardware experiences for over 12 legacy sectors.</p>
            </div>
            <div class="footer-links">
                <h4>Our Fleet</h4>
                <ul>
                    <li><a href="vehicles.jsp">Luxury SUVs</a></li>
                    <li><a href="vehicles.jsp">Executive Sedans</a></li>
                    <li><a href="vehicles.jsp">Cruiser Motorcycles</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <h4>Enterprise Care</h4>
                <ul>
                    <li><a href="#">Security Guidelines</a></li>
                    <li><a href="#">Roadside Support Map</a></li>
                    <li><a href="#">Insurance Policies</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; 2026 Gaadiwala System. All Infrastructure Rights Reserved. Designed for Professional Portfolio Deployment.
        </div>
    </footer>

</body>
</html>