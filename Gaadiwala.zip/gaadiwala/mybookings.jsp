<%@ page import="java.sql.*"%><table border=1><tr><th>ID</th><th>Vehicle ID</th><th>Date</th></tr>
<%
Class.forName("com.mysql.cj.jdbc.Driver");
Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala","root","Shubham@4688");
ResultSet r=c.createStatement().executeQuery("select * from bookings");
while(r.next()){ %><tr><td><%=r.getInt("id")%></td><td><%=r.getInt("vehicle_id")%></td><td><%=r.getDate("booking_date")%></td></tr><% } %></table>