<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%
    // 1. DATA PRE-FETCH & FALLBACK CORE
    List<Map<String, String>> vehicleList = new ArrayList<Map<String, String>>();
    boolean usingMockData = false;
    String runtimeNotice = "";

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;

    try { 
        Class.forName("com.mysql.cj.jdbc.Driver");
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
        } catch (Exception e1) {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
        }
        
        stmt = conn.createStatement(); 
        rs = stmt.executeQuery("SELECT * FROM vehicles");
        
        while(rs.next()) { 
            Map<String, String> vehicle = new HashMap<String, String>();
            vehicle.put("id", String.valueOf(rs.getInt("id")));
            vehicle.put("name", rs.getString("name"));
            vehicle.put("type", rs.getString("type"));
            vehicle.put("fuel_type", rs.getString("fuel_type"));
            vehicle.put("price", String.valueOf(rs.getDouble("price_per_day")));
            vehicle.put("status", rs.getString("status"));
            
            // UPDATED: Now reading cleanly from your original image_url column
            vehicle.put("image", rs.getString("image_url")); 
            vehicleList.add(vehicle);
        }
    } catch(Exception e) { 
        usingMockData = true;
        runtimeNotice = e.getMessage();
        
        Map<String, String> m1 = new HashMap<String, String>();
        m1.put("id", "101"); m1.put("name", "Mahindra Thar 4x4"); m1.put("type", "Luxury SUV"); m1.put("fuel_type", "Diesel"); m1.put("price", "3200.00"); m1.put("status", "AVAILABLE"); m1.put("image", "mock");
        vehicleList.add(m1);

        Map<String, String> m2 = new HashMap<String, String>();
        m2.put("id", "102"); m2.put("name", "Hyundai i20 Asta"); m2.put("type", "Hatchback"); m2.put("fuel_type", "Petrol"); m2.put("price", "1400.00"); m2.put("status", "AVAILABLE"); m2.put("image", "mock");
        vehicleList.add(m2);

        Map<String, String> m3 = new HashMap<String, String>();
        m3.put("id", "103"); m3.put("name", "Royal Enfield Classic 350"); m3.put("type", "Cruiser Bike"); m3.put("fuel_type", "Petrol"); m3.put("price", "900.00"); m3.put("status", "BOOKED"); m3.put("image", "mock");
        vehicleList.add(m3);
    } finally {
        if(rs != null) try { rs.close(); } catch(Exception e) {}
        if(stmt != null) try { stmt.close(); } catch(Exception e) {}
        if(conn != null) try { conn.close(); } catch(Exception e) {}
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gaadiwala | Premium Fleet Catalog</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --dark-bg: #0f172a;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }
        body { background-color: var(--light-bg); color: var(--text-main); padding-top: 80px; }

        header {
            background-color: rgba(15, 23, 42, 0.95); backdrop-filter: blur(10px); padding: 18px 8%;
            display: flex; justify-content: space-between; align-items: center; position: fixed;
            width: 100%; top: 0; left:0; z-index: 1000; border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        header .logo { color: #ffffff; font-size: 24px; font-weight: 700; text-decoration: none; }
        header .logo span { color: var(--primary); }
        nav { display: flex; align-items: center; gap: 30px; }
        nav a { color: #cbd5e1; text-decoration: none; font-weight: 500; font-size: 15px; }
        nav a.active { color: white; font-weight:600; }
        .nav-btn { background-color: var(--primary); color: white; padding: 9px 20px; border-radius: 6px; font-weight: 600; text-decoration: none; }

        .container { max-width: 1240px; margin: 40px auto; padding: 0 24px; }
        .catalog-header { text-align: center; margin-bottom: 40px; }
        .catalog-header h2 { font-size: 36px; font-weight: 700; color: var(--dark-bg); margin-bottom: 8px; }
        
        .demo-pill { background: #fff7ed; border: 1px solid #ffedd5; color: #c2410c; padding: 12px 20px; border-radius: 8px; margin-bottom: 30px; font-size: 14px; }

        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(310px, 1fr)); gap: 30px; }
        .card { background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; display: flex; flex-direction: column; transition: all 0.3s ease; }
        .card:hover { transform: translateY(-5px); box-shadow: var(--card-shadow); }
        
        .img-container { width: 100%; height: 195px; position: relative; background-color: #cbd5e1; }
        .img-container img { width: 100%; height: 100%; object-fit: cover; }
        
        .status-badge { position: absolute; top: 15px; left: 15px; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .status-available { background: #d1fae5; color: #065f46; }
        .status-booked { background: #fee2e2; color: #991b1b; }

        .card-body { padding: 24px; display: flex; flex-direction: column; flex-grow: 1; }
        .card-title { font-size: 20px; font-weight: 700; color: var(--dark-bg); margin-bottom: 6px; }
        .specs-row { display: flex; gap: 12px; font-size: 13px; color: var(--text-muted); margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid #f1f5f9; }
        .price-tag { font-size: 22px; font-weight: 700; color: #059669; margin-bottom: 15px; }
        .price-tag span { font-size: 14px; color: var(--text-muted); }

        .date-group { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 12px; }
        .date-group label { font-size: 11px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px; }
        .date-control { width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px; outline: none; }
        
        .btn-action { width: 100%; background-color: var(--primary); color: white; padding: 11px; border: none; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; text-align: center; text-decoration: none; display: block; }
        .btn-action:hover { background-color: var(--primary-hover); }
    </style>
</head>
<body>

    <header>
        <a href="index.jsp" class="logo">Gaadi<span>wala</span></a>
        <nav>
            <a href="index.jsp">Home</a>
            <a href="vehicles.jsp" class="active">Vehicles</a>
            <% if(session.getAttribute("user_id") == null) { %>
                <a href="login.jsp">Login</a>
                <a href="register.jsp" class="nav-btn">Sign Up</a>
            <% } else { %>
                <a href="dashboard.jsp">Dashboard</a>
                <a href="LogoutServlet" style="color: #f43f5e;">Logout</a>
            <% } %>
        </nav>
    </header>

    <div class="container">
        <div class="catalog-header">
            <h2>Our Premium Fleet</h2>
            <p>Select from verified, fully insured self-drive vehicles curated for transit conditions.</p>
        </div>

        <% if(usingMockData) { %>
            <div class="demo-pill">
                <strong>💡 Local Connection Sandboxed:</strong> Browser rendering complete. Local database layer noted: <code><%= runtimeNotice %></code>
            </div>
        <% } %>

        <div class="grid">
            <% 
                for(Map<String, String> vehicle : vehicleList) {
                    String id = vehicle.get("id");
                    String vName = vehicle.get("name");
                    String vType = vehicle.get("type");
                    String fuelType = vehicle.get("fuel_type");
                    double price = Double.parseDouble(vehicle.get("price"));
                    String status = vehicle.get("status");
                    String dbImage = vehicle.get("image");

                    String imgUrl = "";
                    
                    // Intelligent URL vs Local Image Asset parser logic
                    if (dbImage != null && (dbImage.startsWith("http://") || dbImage.startsWith("https://"))) {
                        imgUrl = dbImage;
                    } else if (dbImage != null && !dbImage.isEmpty() && !"mock".equals(dbImage)) {
                        imgUrl = "images/" + dbImage;
                    } else {
                        imgUrl = "https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=500&q=80";
                        if(vName.toLowerCase().contains("thar")) {
                            imgUrl = "https://images.unsplash.com/photo-1669023197607-df508b8686cf?auto=format&fit=crop&w=500&q=80";
                        } else if(vName.toLowerCase().contains("classic") || vName.toLowerCase().contains("enfield")) {
                            imgUrl = "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=500&q=80";
                        } else if(vType.toLowerCase().contains("hatchback") || vName.toLowerCase().contains("i20")) {
                            imgUrl = "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?auto=format&fit=crop&w=500&q=80";
                        }
                    }

                    String badgeClass = "AVAILABLE".equalsIgnoreCase(status) ? "status-available" : "status-booked";
                    
                    // Safe String formatting done purely inside raw Java block
                    String formattedPrice = String.format("%,.2f", price);

                    String actionFormHtml = "";
                    if("AVAILABLE".equalsIgnoreCase(status)) {
                        actionFormHtml = "<form action=\"" + request.getContextPath() + "/BookVehicleServlet\" method=\"POST\">" +
                                         "<input type='hidden' name='vehicle_id' value='" + id + "'>" +
                                         "<div class='date-group'>" +
                                         "<div><label>Start Date</label><input type='date' name='start_date' class='date-control' required></div>" +
                                         "<div><label>End Date</label><input type='date' name='end_date' class='date-control' required></div>" +
                                         "</div>" +
                                         "<button type='submit' class='btn-action'>Confirm Reservation</button>" +
                                         "</form>";
                    } else {
                        actionFormHtml = "<button class='btn-action' style='background:#64748b; cursor:not-allowed;' disabled>Currently Reserved</button>";
                    }
            %>
            
            <div class="card">
                <div class="img-container">
                    <span class="status-badge <%= badgeClass %>"><%= status %></span>
                    <img src="<%= imgUrl %>" alt="<%= vName %>">
                </div>
                
                <div class="card-body">
                    <div class="card-title"><%= vName %></div>
                    <div class="specs-row">
                        <span>🏷️ <%= vType %></span>
                        <span>⛽ <%= fuelType %></span>
                    </div>
                    <div class="price-tag">₹<%= formattedPrice %> <span>/ day</span></div>
                    <%= actionFormHtml %>
                </div>
            </div>
            
            <% 
                } 
            %>
        </div>
    </div>
</body>
</html>