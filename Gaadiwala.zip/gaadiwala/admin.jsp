<%@ page import="java.sql.*"%>
<% if("POST".equalsIgnoreCase(request.getMethod())){
Class.forName("com.mysql.cj.jdbc.Driver");
Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala","root","Shubham@4688");
PreparedStatement p=c.prepareStatement("insert into vehicles(vehicle_name,vehicle_type,rent_per_day) values(?,?,?)");
p.setString(1,request.getParameter("name")); p.setString(2,request.getParameter("type")); p.setInt(3,Integer.parseInt(request.getParameter("rent")));
p.executeUpdate(); out.print("Vehicle Added"); c.close(); } %>
<form method='post'><input name='name' placeholder='Vehicle Name'><br><input name='type' placeholder='Type'><br><input name='rent' placeholder='Rent'><br><button>Add Vehicle</button></form>