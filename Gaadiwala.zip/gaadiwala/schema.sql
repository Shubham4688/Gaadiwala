USE gaadiwala;

SELECT * FROM vehicles;