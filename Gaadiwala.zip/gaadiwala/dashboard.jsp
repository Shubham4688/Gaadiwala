<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    // 1. SESSION PROTECTION LAYER: Prevent primitive unboxing crashes if null
    Object userIdObj = session.getAttribute("user_id");
    Object userNameObj = session.getAttribute("user_name");

    if (userIdObj == null) {
        // If no user session is valid, cleanly reroute to the login interface
        response.sendRedirect("login.jsp");
        return; 
    }

    int uId = (Integer) userIdObj;
    String userName = (String) userNameObj;
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gaadiwala | Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #0f172a;
            --background: #f8fafc;
            --surface: #ffffff;
            --text-main: #334155;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --success: #16a34a;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            margin: 0;
            padding: 0;
        }

        /* Fixed Header Styling: Premium Dark Theme */
        header {
            background: #0f172a; /* Deep Dark Slate */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 5%;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ffffff; /* White text */
            text-decoration: none;
        }

        .logo span {
            color: #3b82f6; /* Accent Blue for "wala" */
        }

        nav a {
            text-decoration: none;
            color: #cbd5e1; /* Subtle Silver Link Text */
            font-weight: 500;
            margin-left: 1.5rem;
            padding: 0.5rem 0.85rem;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        /* Dark Mode Highlighting for Active/Hover links */
        nav a:hover, nav a.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.1);
        }

        /* Dashboard Container Layout */
        .dashboard-container {
            max-width: 1200px;
            margin: 2.5rem auto;
            padding: 0 1.5rem;
        }

        .welcome-hero {
            background: linear-gradient(135deg, var(--secondary) 0%, #1e293b 100%);
            color: white;
            padding: 2.5rem;
            border-radius: 1rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .welcome-hero h2 {
            margin: 0;
            font-size: 2rem;
            font-weight: 600;
        }

        .welcome-hero p {
            margin: 0.5rem 0 0 0;
            color: #94a3b8;
            font-weight: 300;
        }

        /* Professional Card-Table Frame */
        .table-card {
            background: var(--surface);
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            border: 1px solid var(--border);
            overflow: hidden;
        }

        .table-header-title {
            padding: 1.5rem;
            margin: 0;
            font-size: 1.15rem;
            font-weight: 600;
            border-bottom: 1px solid var(--border);
            background-color: #fafafa;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: #f1f5f9;
            color: var(--text-main);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 1rem 1.5rem;
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--border);
            font-size: 0.95rem;
            color: var(--text-main);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        /* Contextual Status Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .badge-pending {
            background-color: #fef3c7;
            color: #d97706;
        }

        .badge-confirmed {
            background-color: #dcfce7;
            color: #15803d;
        }

        .badge-cancelled {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        /* Empty/Fallback State Designs */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--text-muted);
        }

        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
        }

        .price-tag {
            font-weight: 600;
            color: var(--secondary);
        }
    </style>
</head>
<body>
    <header>
        <a href="index.jsp" class="logo">Gaadi<span>wala</span></a>
        <nav>
            <a href="index.jsp">Home</a> 
            <a href="vehicles.jsp">Vehicles</a>
            <a href="dashboard.jsp" class="active">Dashboard</a>
            <a href="LogoutServlet">Logout</a>
        </nav>
    </header>
    
    <div class="dashboard-container">
        <div class="welcome-hero">
            <h2>Welcome back, <%= userName %>! 👋</h2>
            <p>Manage your reservations, check deployment updates, and review your rental history records.</p>
        </div>
        
        <div class="table-card">
            <h3 class="table-header-title">Your Rental Reservations</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Vehicle Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Total Cost</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% 
                        Connection c = null;
                        PreparedStatement ps = null;
                        ResultSet rs = null;
                        try { 
                            Class.forName("com.mysql.cj.jdbc.Driver");
                            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/gaadiwala", "root", "Shubham@4688");
                            
                            String query = "SELECT b.id, v.name, b.start_date, b.end_date, b.total_price, b.status " +
                                           "FROM bookings b JOIN vehicles v ON b.vehicle_id = v.id WHERE b.user_id = ?";
                            ps = c.prepareStatement(query);
                            ps.setInt(1, uId); 
                            rs = ps.executeQuery();
                            
                            boolean hasBookings = false;
                            while(rs.next()) { 
                                hasBookings = true;
                                String status = rs.getString("status") != null ? rs.getString("status").toLowerCase() : "pending";
                                
                                // Assign context class names based on actual status strings dynamically
                                String badgeClass = "badge-pending";
                                if (status.equals("confirmed") || status.equals("approved") || status.equals("success")) {
                                    badgeClass = "badge-confirmed";
                                } else if (status.equals("cancelled") || status.equals("rejected")) {
                                    badgeClass = "badge-cancelled";
                                }
                        %>
                            <tr>
                                <td style="font-weight: 600; color: var(--primary);">#<%= rs.getInt("id") %></td>
                                <td style="font-weight: 500;"><%= rs.getString("name") %></td>
                                <td><%= rs.getDate("start_date") %></td>
                                <td><%= rs.getDate("end_date") %></td>
                                <td class="price-tag">₹<%= String.format("%,.2f", rs.getDouble("total_price")) %></td>
                                <td>
                                    <span class="badge <%= badgeClass %>"><%= rs.getString("status") %></span>
                                </td>
                            </tr>
                        <% 
                            } 
                            if (!hasBookings) { 
                        %>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <span class="empty-state-icon">🚗</span>
                                        <p style="margin: 0; font-size: 1.1rem; font-weight: 500;">No Reservations Found</p>
                                        <p style="margin: 0.25rem 0 0 0; font-size: 0.9rem;">You haven't reserved any vehicles yet. Explore our fleet to get started!</p>
                                    </div>
                                </td>
                            </tr>
                        <% 
                            }
                        } catch(Exception e) { 
                            out.println("<tr><td colspan='6' style='padding:24px; color:#b91c1c; text-align:center; font-weight:500;'>Error fetching database records: " + e.getMessage() + "</td></tr>");
                        } finally {
                            if(rs != null) try { rs.close(); } catch(Exception e) {}
                            if(ps != null) try { ps.close(); } catch(Exception e) {}
                            if(c != null) try { c.close(); } catch(Exception e) {}
                        }
                        %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>